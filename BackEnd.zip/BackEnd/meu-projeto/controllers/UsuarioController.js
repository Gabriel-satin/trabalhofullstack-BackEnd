const { User } = require("../models");

const createUser = async (req, res) => {
  const { cpf, telefone, nome } = req.body;

  try {
    if (!cpf || !telefone || !nome) {
      return res
        .status(400)
        .json({ error: "Todos os campos são obrigatórios!" });
    }

    if (cpf.length !== 11) {
      return res
        .status(400)
        .json({ error: "O CPF deve ter exatamente 11 caracteres!" });
    }

    if (telefone.length < 10 || telefone.length > 11) {
      return res
        .status(400)
        .json({ error: "O telefone deve ter entre 10 e 11 caracteres!" });
    }

    if (nome.length < 3 || nome.length > 50) {
      return res
        .status(400)
        .json({ error: "O nome deve ter entre 3 e 50 caracteres!" });
    }

    const newUser = await User.create({ cpf, telefone, nome });

    res.status(201).json(newUser);
  } catch (error) {
    console.error("Erro ao criar usuário:", error);
    res.status(500).json({ error: "Erro ao criar usuário." });
  }
};

module.exports = {
  createUser,
};
