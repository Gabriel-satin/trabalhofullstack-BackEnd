module.exports = {
  development: {
    username: "postgres",
    password: "271296",
    database: "apinodecep",
    host: "127.0.0.1",
    dialect: "postgres",
  },
  test: {
    username: "postgres",
    password: "271296",
    database: "apinodecep_test",
    host: "127.0.0.1",
    dialect: "postgres",
  },
  production: {
    username: "postgres",
    password: "271296",
    database: "apinodecep_production",
    host: "127.0.0.1",
    dialect: "postgres",
  },
};
